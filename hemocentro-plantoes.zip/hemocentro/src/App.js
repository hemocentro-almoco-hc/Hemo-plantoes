import React, { useState, useEffect } from "react";
import { db } from "./firebase/config";
import { ref, onValue, set, push, update, serverTimestamp } from "firebase/database";
import LoginPage from "./pages/LoginPage";
import GestorDashboard from "./pages/GestorDashboard";
import PlantonistaDashboard from "./pages/PlantonistaDashboard";

export default function App() {
  const [user, setUser] = useState(() => {
    const s = sessionStorage.getItem("hemo_user");
    return s ? JSON.parse(s) : null;
  });

  function handleLogin(userData) {
    sessionStorage.setItem("hemo_user", JSON.stringify(userData));
    setUser(userData);
  }

  function handleLogout() {
    sessionStorage.removeItem("hemo_user");
    setUser(null);
  }

  if (!user) return <LoginPage onLogin={handleLogin} db={db} />;
  if (user.role === "gestor") return <GestorDashboard user={user} onLogout={handleLogout} db={db} />;
  return <PlantonistaDashboard user={user} onLogout={handleLogout} db={db} />;
}
