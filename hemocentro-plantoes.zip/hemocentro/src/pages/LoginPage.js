import React, { useState } from "react";
import { ref, get } from "firebase/database";

const S = {
  root: { minHeight: "100vh", background: "linear-gradient(135deg, #0D1B2A 0%, #1a3a5c 60%, #0D1B2A 100%)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Plus Jakarta Sans', sans-serif" },
  card: { background: "#fff", borderRadius: 20, padding: "40px 36px", width: 380, maxWidth: "95vw", boxShadow: "0 24px 80px rgba(0,0,0,0.4)" },
  logoWrap: { display: "flex", alignItems: "center", gap: 12, justifyContent: "center", marginBottom: 28 },
  logoIcon: { fontSize: 40 },
  logoText: { textAlign: "left" },
  logoName: { fontWeight: 800, fontSize: 20, color: "#0D1B2A", lineHeight: 1 },
  logoSub: { fontSize: 12, color: "#90A4AE", marginTop: 2 },
  title: { fontWeight: 700, fontSize: 22, color: "#0D1B2A", textAlign: "center", marginBottom: 6 },
  subtitle: { fontSize: 13, color: "#90A4AE", textAlign: "center", marginBottom: 28 },
  label: { display: "block", fontWeight: 600, fontSize: 13, color: "#555", marginBottom: 6 },
  input: { width: "100%", border: "1.5px solid #E0E7EF", borderRadius: 10, padding: "11px 14px", fontSize: 15, outline: "none", boxSizing: "border-box", fontFamily: "inherit", transition: "border 0.2s" },
  group: { marginBottom: 18 },
  btn: { width: "100%", background: "#1565C0", color: "#fff", border: "none", borderRadius: 10, padding: "13px 0", fontWeight: 700, fontSize: 16, cursor: "pointer", marginTop: 8, fontFamily: "inherit", transition: "background 0.2s" },
  error: { background: "#FFEBEE", color: "#C62828", borderRadius: 8, padding: "10px 14px", fontSize: 13, marginTop: 14, textAlign: "center" },
  hint: { fontSize: 12, color: "#90A4AE", textAlign: "center", marginTop: 18, lineHeight: 1.6 },
};

export default function LoginPage({ onLogin, db }) {
  const [crm, setCrm] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleLogin() {
    if (!crm || !senha) { setError("Preencha CRM e senha."); return; }
    setLoading(true);
    setError("");
    try {
      const key = `crm_${crm.trim()}`;
      const snap = await get(ref(db, `medicos/${key}`));
      if (!snap.exists()) { setError("CRM não encontrado."); setLoading(false); return; }
      const data = snap.val();
      if (data.senha !== senha.trim()) { setError("Senha incorreta."); setLoading(false); return; }
      onLogin({ ...data, key });
    } catch (e) {
      setError("Erro de conexão. Verifique sua internet.");
    }
    setLoading(false);
  }

  return (
    <div style={S.root}>
      <div style={S.card}>
        <div style={S.logoWrap}>
          <span style={S.logoIcon}>🩸</span>
          <div style={S.logoText}>
            <div style={S.logoName}>Hemocentro</div>
            <div style={S.logoSub}>João Pessoa — PB</div>
          </div>
        </div>
        <div style={S.title}>Acesso ao Sistema</div>
        <div style={S.subtitle}>Gestão de Plantões Médicos</div>

        <div style={S.group}>
          <label style={S.label}>CRM</label>
          <input style={S.input} placeholder="Ex: 11707" value={crm} onChange={e => setCrm(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>
        <div style={S.group}>
          <label style={S.label}>Senha</label>
          <input style={S.input} type="password" placeholder="••••" value={senha} onChange={e => setSenha(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>

        {error && <div style={S.error}>⚠ {error}</div>}

        <button style={{ ...S.btn, opacity: loading ? 0.7 : 1 }} onClick={handleLogin} disabled={loading}>
          {loading ? "Verificando..." : "Entrar"}
        </button>

        <div style={S.hint}>
          Login: seu CRM (sem CRM/PB)<br />
          Senha padrão: <strong>1234</strong>
        </div>
      </div>
    </div>
  );
}
