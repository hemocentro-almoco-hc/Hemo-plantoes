import React, { useState, useEffect } from "react";
import { ref, onValue, push, update } from "firebase/database";

function fmtTime(ts) { if (!ts) return "—"; try { return new Date(ts).toLocaleString("pt-BR"); } catch { return ts; } }
function now() { return new Date().toLocaleString("pt-BR"); }

function Clock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setT(new Date()), 1000); return () => clearInterval(i); }, []);
  const p = n => String(n).padStart(2, "0");
  return `${p(t.getDate())}/${p(t.getMonth()+1)}/${t.getFullYear()} ${p(t.getHours())}:${p(t.getMinutes())}:${p(t.getSeconds())}`;
}

const S = {
  root: { minHeight: "100vh", background: "#F0F4F8", fontFamily: "'Plus Jakarta Sans', sans-serif" },
  topbar: { background: "#0D1B2A", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" },
  content: { maxWidth: 700, margin: "0 auto", padding: "20px 16px" },
  card: { background: "#fff", borderRadius: 14, padding: 20, marginBottom: 16, boxShadow: "0 2px 8px #0001" },
  cardTitle: { fontWeight: 700, fontSize: 16, color: "#1a1a2e", marginBottom: 14 },
  btnGreen: { background: "#2E7D32", color: "#fff", border: "none", borderRadius: 10, padding: "14px 0", width: "100%", fontWeight: 700, fontSize: 16, cursor: "pointer", fontFamily: "inherit", marginBottom: 10 },
  btnRed: { background: "#C62828", color: "#fff", border: "none", borderRadius: 10, padding: "14px 0", width: "100%", fontWeight: 700, fontSize: 16, cursor: "pointer", fontFamily: "inherit" },
  btnDisabled: { background: "#E0E7EF", color: "#aaa", border: "none", borderRadius: 10, padding: "14px 0", width: "100%", fontWeight: 700, fontSize: 16, cursor: "not-allowed", fontFamily: "inherit" },
  badge: (c, bg) => ({ background: bg, color: c, borderRadius: 20, padding: "3px 12px", fontSize: 12, fontWeight: 600 }),
  table: { width: "100%", borderCollapse: "collapse" },
  th: { textAlign: "left", fontSize: 12, color: "#90A4AE", fontWeight: 600, padding: "6px 8px", borderBottom: "1px solid #F0F4F8" },
  td: { padding: "9px 8px", fontSize: 13, color: "#333" },
  tr: { borderBottom: "1px solid #F9FAFB" },
  liveTag: { display: "inline-flex", alignItems: "center", gap: 4, background: "#E8F5E9", color: "#2E7D32", borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700 },
};

export default function PlantonistaDashboard({ user, onLogout, db }) {
  const [meuPlantao, setMeuPlantao] = useState(null);
  const [todosMeusPlantoes, setTodosMeusPlantoes] = useState([]);
  const [escalaGeral, setEscalaGeral] = useState([]);
  const [setores, setSetores] = useState({});
  const [msg, setMsg] = useState("");

  useEffect(() => {
    // Ouvir plantões em tempo real
    const un = onValue(ref(db, "plantoes"), snap => {
      const v = snap.val() || {};
      const lista = Object.entries(v).map(([k, p]) => ({ ...p, key: k }));
      const meus = lista.filter(p => p.medicoKey === user.key);
      const ativo = meus.find(p => p.status === "ativo") || null;
      setMeuPlantao(ativo);
      setTodosMeusPlantoes(meus.sort((a, b) => new Date(b.inicio) - new Date(a.inicio)));
      // Escala geral: ativos de todos
      setEscalaGeral(lista.filter(p => p.status === "ativo"));
    });
    const un2 = onValue(ref(db, "setores"), snap => setSetores(snap.val() || {}));
    return () => { un(); un2(); };
  }, [db, user.key]);

  function iniciarPlantao() {
    if (meuPlantao) return;
    const entry = {
      medicoKey: user.key,
      medicoNome: user.nome,
      medicoCrm: user.crm,
      setorId: null,
      setorNome: user.setor || "A definir",
      status: "ativo",
      inicio: new Date().toISOString(),
      fim: null,
      iniciadoPor: user.nome,
    };
    push(ref(db, "plantoes"), entry);
    push(ref(db, "notificacoes"), { tipo: "inicio", texto: `${user.nome} iniciou plantão em ${user.setor || "setor a definir"}`, hora: now(), cor: "green" });
    setMsg("✅ Plantão iniciado! Registro gravado com horário atual.");
    setTimeout(() => setMsg(""), 4000);
  }

  function encerrarPlantao() {
    if (!meuPlantao) return;
    update(ref(db, `plantoes/${meuPlantao.key}`), { status: "encerrado", fim: new Date().toISOString() });
    push(ref(db, "notificacoes"), { tipo: "fim", texto: `${user.nome} encerrou plantão em ${meuPlantao.setorNome}`, hora: now(), cor: "red" });
    setMsg("🔴 Plantão encerrado! Registro salvo.");
    setTimeout(() => setMsg(""), 4000);
  }

  const setorList = Object.values(setores);

  return (
    <div style={S.root}>
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style>
      {/* Topbar */}
      <div style={S.topbar}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 28 }}>🩸</span>
          <div>
            <div style={{ color: "#fff", fontWeight: 800, fontSize: 15 }}>Hemocentro JP</div>
            <div style={{ color: "#90A4AE", fontSize: 11 }}>Plantonista</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={S.liveTag}>● AO VIVO</span>
          <div style={{ textAlign: "right" }}>
            <div style={{ color: "#fff", fontSize: 13, fontWeight: 600 }}>{user.nome.split(" ")[0]}</div>
            <div style={{ color: "#90A4AE", fontSize: 11 }}>CRM {user.crm}</div>
          </div>
          <button style={{ background: "none", border: "1px solid #546E7A", color: "#90A4AE", borderRadius: 8, padding: "6px 12px", cursor: "pointer", fontSize: 12 }} onClick={onLogout}>Sair</button>
        </div>
      </div>

      <div style={S.content}>
        {/* Bater ponto */}
        <div style={S.card}>
          <div style={S.cardTitle}>🕐 Bater Ponto</div>

          {/* Clock */}
          <div style={{ background: "#F7F9FC", borderRadius: 10, padding: "12px 16px", marginBottom: 14, display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 20 }}>🕐</span>
            <span style={{ fontFamily: "monospace", fontSize: 14, color: "#333", fontWeight: 600 }}><Clock /></span>
          </div>

          {/* Status */}
          {meuPlantao ? (
            <div style={{ background: "#E8F5E9", borderRadius: 10, padding: "12px 16px", marginBottom: 14, border: "1px solid #C8E6C9" }}>
              <div style={{ color: "#2E7D32", fontWeight: 700, fontSize: 14, marginBottom: 4 }}>✅ Plantão em andamento</div>
              <div style={{ color: "#555", fontSize: 13 }}>Setor: <strong>{meuPlantao.setorNome}</strong></div>
              <div style={{ color: "#555", fontSize: 13 }}>Iniciado em: <strong style={{ fontFamily: "monospace" }}>{fmtTime(meuPlantao.inicio)}</strong></div>
            </div>
          ) : (
            <div style={{ background: "#FFF3E0", borderRadius: 10, padding: "12px 16px", marginBottom: 14, border: "1px solid #FFE0B2" }}>
              <div style={{ color: "#E65100", fontWeight: 600, fontSize: 13 }}>⏸ Nenhum plantão ativo. Clique em "Iniciar Plantão" para registrar sua entrada.</div>
            </div>
          )}

          {msg && <div style={{ background: "#E3F2FD", borderRadius: 8, padding: "10px 14px", marginBottom: 12, color: "#1565C0", fontWeight: 600, fontSize: 13 }}>{msg}</div>}

          <button style={meuPlantao ? S.btnDisabled : S.btnGreen} onClick={iniciarPlantao} disabled={!!meuPlantao}>
            ▶ Iniciar Plantão
          </button>
          <button style={!meuPlantao ? S.btnDisabled : S.btnRed} onClick={encerrarPlantao} disabled={!meuPlantao}>
            ■ Encerrar Plantão
          </button>
        </div>

        {/* Minha info */}
        <div style={S.card}>
          <div style={S.cardTitle}>👤 Meus Dados</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[["Nome", user.nome], ["CRM", user.crm], ["Matrícula", user.matricula || "—"], ["Setor", user.setor || "A definir"]].map(([l, v]) => (
              <div key={l} style={{ background: "#F7F9FC", borderRadius: 8, padding: "10px 12px" }}>
                <div style={{ fontSize: 11, color: "#90A4AE", fontWeight: 600 }}>{l}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: "#1a1a2e", marginTop: 2 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Meu histórico */}
        <div style={S.card}>
          <div style={S.cardTitle}>📋 Meu Histórico de Plantões</div>
          {todosMeusPlantoes.length === 0 ? (
            <div style={{ color: "#aaa", fontSize: 14, textAlign: "center", padding: 16 }}>Nenhum plantão registrado ainda.</div>
          ) : (
            <table style={S.table}>
              <thead><tr>{["Setor", "Início", "Fim", "Duração", "Status"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>
                {todosMeusPlantoes.map(p => {
                  const dur = p.fim && p.inicio ? Math.round((new Date(p.fim) - new Date(p.inicio)) / 60000) + " min" : "Em curso";
                  return (
                    <tr key={p.key} style={S.tr}>
                      <td style={S.td}>{p.setorNome}</td>
                      <td style={S.td}><span style={{ fontFamily: "monospace", fontSize: 12 }}>{fmtTime(p.inicio)}</span></td>
                      <td style={S.td}><span style={{ fontFamily: "monospace", fontSize: 12 }}>{fmtTime(p.fim)}</span></td>
                      <td style={S.td}>{dur}</td>
                      <td style={S.td}><span style={p.status === "ativo" ? S.badge("#2E7D32", "#E8F5E9") : S.badge("#555", "#F0F4F8")}>● {p.status}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Escala geral ao vivo */}
        <div style={S.card}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
            <span style={S.cardTitle}>Escala de Hoje — Ao Vivo</span>
            <span style={{ ...S.liveTag, fontSize: 10 }}>● TEMPO REAL</span>
          </div>
          {setorList.map(s => {
            const neste = escalaGeral.filter(p => p.setorId === s.id);
            return (
              <div key={s.id} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: s.cor + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>{s.icone}</div>
                  <span style={{ fontWeight: 700, color: s.cor, fontSize: 14 }}>{s.nome}</span>
                  <span style={{ fontSize: 12, color: "#aaa" }}>({neste.length}/{s.vagas})</span>
                </div>
                {neste.length === 0 ? (
                  <div style={{ fontSize: 13, color: "#aaa", paddingLeft: 36 }}>Sem médicos no plantão</div>
                ) : neste.map(p => (
                  <div key={p.key} style={{ display: "flex", alignItems: "center", gap: 8, paddingLeft: 36, paddingBottom: 4 }}>
                    <span style={{ fontSize: 13, color: "#333", fontWeight: p.medicoKey === user.key ? 700 : 400 }}>
                      {p.medicoNome} {p.medicoKey === user.key ? "👈 (você)" : ""}
                    </span>
                    <span style={{ fontSize: 11, color: "#90A4AE", fontFamily: "monospace" }}>desde {fmtTime(p.inicio)}</span>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
