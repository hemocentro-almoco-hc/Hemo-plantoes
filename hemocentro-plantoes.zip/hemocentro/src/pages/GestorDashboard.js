import React, { useState, useEffect } from "react";
import { ref, onValue, set, push, update, remove } from "firebase/database";

const SETORES_DEFAULT = [
  { id: "triagem",    nome: "Triagem Clínica",           icone: "🩺", cor: "#2196F3", vagas: 5 },
  { id: "orientacao", nome: "Orientação",                icone: "💬", cor: "#4CAF50", vagas: 4 },
  { id: "intercorr",  nome: "Intercorrências",           icone: "⚠️", cor: "#FF9800", vagas: 3 },
  { id: "transfusao", nome: "Ambulatório de Transfusão", icone: "🩸", cor: "#9C27B0", vagas: 4 },
];

function now() { return new Date().toLocaleString("pt-BR"); }
function fmtTime(ts) { if (!ts) return "—"; try { return new Date(ts).toLocaleString("pt-BR"); } catch { return ts; } }

const S = {
  root: { display: "flex", height: "100vh", fontFamily: "'Plus Jakarta Sans', sans-serif", background: "#F0F4F8", overflow: "hidden" },
  sidebar: { background: "#0D1B2A", width: 220, display: "flex", flexDirection: "column", overflowY: "auto", flexShrink: 0 },
  logo: { display: "flex", alignItems: "center", gap: 10, padding: "20px 16px 12px", borderBottom: "1px solid #1a2d42" },
  logoName: { color: "#fff", fontWeight: 800, fontSize: 15 },
  logoSub: { color: "#90A4AE", fontSize: 11 },
  nav: { flex: 1, padding: "8px" },
  navBtn: { display: "flex", alignItems: "center", gap: 10, padding: "9px 10px", borderRadius: 8, border: "none", cursor: "pointer", width: "100%", textAlign: "left", fontSize: 14, fontWeight: 500, marginBottom: 2, whiteSpace: "nowrap", background: "transparent", color: "#B0BEC5" },
  navBtnActive: { background: "#1565C0 !important", color: "#fff" },
  main: { flex: 1, display: "flex", flexDirection: "column", minWidth: 0, overflow: "hidden" },
  topbar: { background: "#fff", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", height: 60, borderBottom: "1px solid #E0E7EF", flexShrink: 0, boxShadow: "0 1px 4px #0001" },
  content: { flex: 1, overflowY: "auto", padding: 20 },
  card: { background: "#fff", borderRadius: 12, padding: 16, boxShadow: "0 1px 4px #0001" },
  cardTitle: { fontWeight: 700, fontSize: 15, color: "#1a1a2e", marginBottom: 12 },
  table: { width: "100%", borderCollapse: "collapse" },
  th: { textAlign: "left", fontSize: 12, color: "#90A4AE", fontWeight: 600, padding: "6px 8px", borderBottom: "1px solid #F0F4F8" },
  td: { padding: "9px 8px", fontSize: 13, color: "#333", verticalAlign: "middle" },
  tr: { borderBottom: "1px solid #F9FAFB" },
  badge: (c, bg) => ({ background: bg || "#E8F5E9", color: c || "#2E7D32", borderRadius: 20, padding: "2px 10px", fontSize: 12, fontWeight: 500 }),
  btnPrimary: { background: "#1565C0", color: "#fff", border: "none", borderRadius: 8, padding: "9px 18px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit" },
  btnDanger: { background: "#FFEBEE", color: "#C62828", border: "none", borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 12, fontWeight: 500 },
  btnSuccess: { background: "#E8F5E9", color: "#2E7D32", border: "none", borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 12, fontWeight: 500 },
  input: { width: "100%", border: "1.5px solid #E0E7EF", borderRadius: 8, padding: "8px 10px", fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" },
  select: { width: "100%", border: "1.5px solid #E0E7EF", borderRadius: 8, padding: "8px 10px", fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#fff" },
  label: { display: "block", fontWeight: 600, fontSize: 13, color: "#555", marginBottom: 5, marginTop: 12 },
  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 },
  modal: { background: "#fff", borderRadius: 14, padding: 0, width: 440, maxWidth: "95vw", boxShadow: "0 8px 32px #0003" },
  modalHead: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 20px", borderBottom: "1px solid #F0F4F8" },
  modalBody: { padding: 20 },
  grid4: { display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 16 },
  sectorCard: { background: "#fff", borderRadius: 12, padding: 16, boxShadow: "0 1px 4px #0001" },
  row2: { display: "flex", gap: 16, alignItems: "flex-start" },
  liveTag: { display: "inline-flex", alignItems: "center", gap: 4, background: "#E8F5E9", color: "#2E7D32", borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700, animation: "pulse 2s infinite" },
};

export default function GestorDashboard({ user, onLogout, db }) {
  const [page, setPage] = useState("dashboard");
  const [medicos, setMedicos] = useState({});
  const [plantoes, setPlantoes] = useState({});
  const [setores, setSetores] = useState({});
  const [modal, setModal] = useState(null);
  const [newPlantao, setNewPlantao] = useState({ medicoKey: "", setorId: "", data: "" });
  const [newMedico, setNewMedico] = useState({ nome: "", crm: "", matricula: "", funcao: "Médico(a)", setor: "", senha: "1234" });
  const [senhaEdit, setSenhaEdit] = useState({ key: "", nova: "" });

  useEffect(() => {
    const uns = [
      onValue(ref(db, "medicos"), snap => setMedicos(snap.val() || {})),
      onValue(ref(db, "plantoes"), snap => setPlantoes(snap.val() || {})),
      onValue(ref(db, "setores"), snap => {
        const v = snap.val();
        if (v) setSetores(v);
        else {
          // seed setores default
          const obj = {};
          SETORES_DEFAULT.forEach(s => { obj[s.id] = s; });
          set(ref(db, "setores"), obj);
        }
      }),
    ];
    return () => uns.forEach(u => u());
  }, [db]);

  const medicoList = Object.entries(medicos).map(([k, v]) => ({ ...v, key: k })).filter(m => m.role !== "gestor");
  const setorList = Object.values(setores);
  const plantaoList = Object.entries(plantoes).map(([k, v]) => ({ ...v, key: k }));
  const ativos = plantaoList.filter(p => p.status === "ativo");

  // Resumo de hoje
  const hoje = new Date().toLocaleDateString("pt-BR");
  const plantaoHoje = plantaoList.filter(p => p.inicio && p.inicio.startsWith(hoje.split("/").reverse().join("-")) || (p.inicio && fmtTime(p.inicio).includes(hoje.split("/")[0])));

  function iniciarPlantao() {
    if (!newPlantao.medicoKey || !newPlantao.setorId) return;
    const medico = medicos[newPlantao.medicoKey];
    const setor = setores[newPlantao.setorId];
    const entry = {
      medicoKey: newPlantao.medicoKey,
      medicoNome: medico.nome,
      medicoCrm: medico.crm,
      setorId: newPlantao.setorId,
      setorNome: setor.nome,
      status: "ativo",
      inicio: new Date().toISOString(),
      fim: null,
      iniciadoPor: user.nome,
    };
    push(ref(db, "plantoes"), entry);
    // Notificação
    push(ref(db, "notificacoes"), { tipo: "inicio", texto: `${medico.nome} iniciou plantão em ${setor.nome}`, hora: now(), cor: "green" });
    setModal(null);
    setNewPlantao({ medicoKey: "", setorId: "", data: "" });
  }

  function encerrarPlantao(key, p) {
    update(ref(db, `plantoes/${key}`), { status: "encerrado", fim: new Date().toISOString(), encerradoPor: user.nome });
    push(ref(db, "notificacoes"), { tipo: "fim", texto: `${p.medicoNome} encerrou plantão em ${p.setorNome}`, hora: now(), cor: "red" });
  }

  function adicionarMedico() {
    if (!newMedico.nome || !newMedico.crm) return;
    const key = `crm_${newMedico.crm.trim()}`;
    set(ref(db, `medicos/${key}`), { ...newMedico, role: "plantonista" });
    setModal(null);
    setNewMedico({ nome: "", crm: "", matricula: "", funcao: "Médico(a)", setor: "", senha: "1234" });
  }

  function salvarSenha() {
    if (!senhaEdit.nova) return;
    update(ref(db, `medicos/${senhaEdit.key}`), { senha: senhaEdit.nova });
    setModal(null);
  }

  function gerarRelatorio(tipo) {
    const linhas = [];
    if (tipo === "chegada") {
      linhas.push("RELATÓRIO DE CHEGADA — " + hoje);
      linhas.push("=" .repeat(60));
      linhas.push("Médico | CRM | Setor | Início");
      linhas.push("-".repeat(60));
      plantaoList.forEach(p => { linhas.push(`${p.medicoNome} | CRM ${p.medicoCrm} | ${p.setorNome} | ${fmtTime(p.inicio)}`); });
    } else if (tipo === "fechamento") {
      linhas.push("RELATÓRIO DE FECHAMENTO — " + hoje);
      linhas.push("=".repeat(60));
      linhas.push("Médico | CRM | Setor | Início | Fim | Duração");
      linhas.push("-".repeat(60));
      plantaoList.filter(p => p.fim).forEach(p => {
        const dur = p.fim && p.inicio ? Math.round((new Date(p.fim) - new Date(p.inicio)) / 60000) + " min" : "—";
        linhas.push(`${p.medicoNome} | CRM ${p.medicoCrm} | ${p.setorNome} | ${fmtTime(p.inicio)} | ${fmtTime(p.fim)} | ${dur}`);
      });
    } else if (tipo === "completo") {
      linhas.push("RELATÓRIO COMPLETO DE PLANTÕES");
      linhas.push("=".repeat(60));
      plantaoList.forEach(p => {
        const dur = p.fim && p.inicio ? Math.round((new Date(p.fim) - new Date(p.inicio)) / 60000) + " min" : "Em curso";
        linhas.push(`[${p.status.toUpperCase()}] ${p.medicoNome} | CRM ${p.medicoCrm}`);
        linhas.push(`  Setor: ${p.setorNome}`);
        linhas.push(`  Início: ${fmtTime(p.inicio)}  |  Fim: ${fmtTime(p.fim)}  |  Duração: ${dur}`);
        linhas.push("");
      });
    } else if (tipo === "ausencias") {
      const comPlantao = new Set(plantaoList.map(p => p.medicoKey));
      const ausentes = medicoList.filter(m => !comPlantao.has(m.key));
      linhas.push("RELATÓRIO DE AUSÊNCIAS — " + hoje);
      linhas.push("=".repeat(60));
      ausentes.forEach(m => linhas.push(`${m.nome} | CRM ${m.crm} | ${m.setor || "Sem setor"}`));
    }
    const blob = new Blob([linhas.join("\n")], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = `relatorio_${tipo}_${hoje.replace(/\//g, "-")}.txt`; a.click();
  }

  const navItems = [
    { id: "dashboard", icon: "⊞", label: "Dashboard" },
    { id: "plantoes",  icon: "📅", label: "Plantões" },
    { id: "medicos",   icon: "👥", label: "Médicos" },
    { id: "relatorios",icon: "📊", label: "Relatórios" },
    { id: "notificacoes", icon: "🔔", label: "Notificações" },
  ];

  return (
    <div style={S.root}>
      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} } button:hover{opacity:0.88}`}</style>
      {/* Sidebar */}
      <aside style={S.sidebar}>
        <div style={S.logo}>
          <span style={{ fontSize: 28 }}>🩸</span>
          <div><div style={S.logoName}>Hemocentro JP</div><div style={S.logoSub}>Gestor</div></div>
        </div>
        <nav style={S.nav}>
          {navItems.map(n => (
            <button key={n.id} style={{ ...S.navBtn, background: page === n.id ? "#1565C0" : "transparent", color: page === n.id ? "#fff" : "#B0BEC5" }} onClick={() => setPage(n.id)}>
              <span style={{ fontSize: 16, width: 20, textAlign: "center" }}>{n.icon}</span> {n.label}
            </button>
          ))}
          <button style={{ ...S.navBtn, color: "#EF5350", marginTop: 16 }} onClick={onLogout}>
            <span style={{ fontSize: 16, width: 20, textAlign: "center" }}>🚪</span> Sair
          </button>
        </nav>
        <div style={{ padding: 12, borderTop: "1px solid #1a2d42", color: "#546E7A", fontSize: 11, textAlign: "center" }}>
          {user.nome}<br />CRM {user.crm}<br />Gestor Administrador<br /><br />v1.0.0
        </div>
      </aside>

      {/* Main */}
      <div style={S.main}>
        <header style={S.topbar}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, color: "#1a1a2e" }}>
              {navItems.find(n => n.id === page)?.label}
              {" "}<span style={S.liveTag}>● AO VIVO</span>
            </div>
            <div style={{ fontSize: 12, color: "#90A4AE" }}>Hemocentro de João Pessoa — Gestão de Plantões Médicos</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#1565C0", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800 }}>G</div>
            <div><div style={{ fontWeight: 600, fontSize: 13 }}>{user.nome.split(" ")[0]}</div><div style={{ fontSize: 11, color: "#90A4AE" }}>Gestor</div></div>
          </div>
        </header>

        <div style={S.content}>
          {page === "dashboard" && <DashboardPage ativos={ativos} medicos={medicoList} plantoes={plantaoList} setores={setorList} setPage={setPage} setModal={setModal} />}
          {page === "plantoes" && <PlantoesPage plantoes={plantaoList} setores={setorList} medicos={medicoList} encerrar={encerrarPlantao} setModal={setModal} />}
          {page === "medicos" && <MedicosPage medicos={medicoList} setores={setorList} setModal={setModal} db={db} />}
          {page === "relatorios" && <RelatoriosPage gerar={gerarRelatorio} plantoes={plantaoList} />}
          {page === "notificacoes" && <NotifPage db={db} />}
        </div>
      </div>

      {/* Modal novo plantão */}
      {modal === "novoPlantao" && (
        <div style={S.overlay} onClick={() => setModal(null)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <div style={S.modalHead}>
              <span style={{ fontWeight: 700, fontSize: 16 }}>Iniciar Plantão</span>
              <button style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "#999" }} onClick={() => setModal(null)}>✕</button>
            </div>
            <div style={S.modalBody}>
              <label style={S.label}>Médico</label>
              <select style={S.select} value={newPlantao.medicoKey} onChange={e => setNewPlantao({ ...newPlantao, medicoKey: e.target.value })}>
                <option value="">Selecione o médico...</option>
                {medicoList.map(m => <option key={m.key} value={m.key}>{m.nome} — CRM {m.crm}</option>)}
              </select>
              <label style={S.label}>Setor</label>
              <select style={S.select} value={newPlantao.setorId} onChange={e => setNewPlantao({ ...newPlantao, setorId: e.target.value })}>
                <option value="">Selecione o setor...</option>
                {setorList.map(s => <option key={s.id} value={s.id}>{s.icone} {s.nome}</option>)}
              </select>
              <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
                <button style={S.btnPrimary} onClick={iniciarPlantao}>✅ Iniciar Plantão</button>
                <button style={{ ...S.btnPrimary, background: "#eee", color: "#555" }} onClick={() => setModal(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal novo médico */}
      {modal === "novoMedico" && (
        <div style={S.overlay} onClick={() => setModal(null)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <div style={S.modalHead}>
              <span style={{ fontWeight: 700, fontSize: 16 }}>Cadastrar Médico</span>
              <button style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "#999" }} onClick={() => setModal(null)}>✕</button>
            </div>
            <div style={S.modalBody}>
              {[["Nome completo", "nome", "Dr(a). Nome Sobrenome"], ["CRM (só números)", "crm", "Ex: 19644"], ["Matrícula", "matricula", "Ex: 929.841-0"]].map(([lb, k, ph]) => (
                <div key={k}>
                  <label style={S.label}>{lb}</label>
                  <input style={S.input} placeholder={ph} value={newMedico[k]} onChange={e => setNewMedico({ ...newMedico, [k]: e.target.value })} />
                </div>
              ))}
              <label style={S.label}>Setor</label>
              <select style={S.select} value={newMedico.setor} onChange={e => setNewMedico({ ...newMedico, setor: e.target.value })}>
                <option value="">Sem setor definido</option>
                {setorList.map(s => <option key={s.id} value={s.nome}>{s.icone} {s.nome}</option>)}
              </select>
              <label style={S.label}>Senha inicial</label>
              <input style={S.input} value={newMedico.senha} onChange={e => setNewMedico({ ...newMedico, senha: e.target.value })} />
              <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
                <button style={S.btnPrimary} onClick={adicionarMedico}>Salvar</button>
                <button style={{ ...S.btnPrimary, background: "#eee", color: "#555" }} onClick={() => setModal(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal editar senha */}
      {modal === "editSenha" && (
        <div style={S.overlay} onClick={() => setModal(null)}>
          <div style={{ ...S.modal, width: 340 }} onClick={e => e.stopPropagation()}>
            <div style={S.modalHead}>
              <span style={{ fontWeight: 700, fontSize: 16 }}>Alterar Senha</span>
              <button style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "#999" }} onClick={() => setModal(null)}>✕</button>
            </div>
            <div style={S.modalBody}>
              <label style={S.label}>Nova senha</label>
              <input style={S.input} value={senhaEdit.nova} onChange={e => setSenhaEdit({ ...senhaEdit, nova: e.target.value })} placeholder="Nova senha" />
              <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                <button style={S.btnPrimary} onClick={salvarSenha}>Salvar</button>
                <button style={{ ...S.btnPrimary, background: "#eee", color: "#555" }} onClick={() => setModal(null)}>Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── SUB-PAGES ───────────────────────────────────────────────────────────────

function DashboardPage({ ativos, medicos, plantoes, setores, setPage, setModal }) {
  const encerrados = plantoes.filter(p => p.status === "encerrado");
  return (
    <div>
      {/* Sector summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 16 }}>
        {setores.map(s => {
          const count = ativos.filter(p => p.setorId === s.id).length;
          return (
            <div key={s.id} style={S.sectorCard}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: s.cor + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{s.icone}</div>
                <span style={{ fontWeight: 700, color: s.cor, fontSize: 13, lineHeight: 1.2 }}>{s.nome}</span>
              </div>
              <div style={{ fontSize: 12, color: "#90A4AE" }}>Médicos no plantão</div>
              <div style={{ fontWeight: 800, fontSize: 28, color: "#1a1a2e" }}>{count} <span style={{ fontWeight: 400, fontSize: 16, color: "#aaa" }}>/ {s.vagas}</span></div>
              <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4 }}>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: count > 0 ? "#4CAF50" : "#FF9800", display: "inline-block" }}></span>
                <span style={{ fontSize: 12, color: "#777" }}>Em andamento</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Two cols */}
      <div style={{ display: "flex", gap: 16 }}>
        <div style={{ flex: 1.6 }}>
          <div style={S.card}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <span style={S.cardTitle}>Plantões em Andamento</span>
              <button style={S.btnPrimary} onClick={() => setModal("novoPlantao")}>+ Novo Plantão</button>
            </div>
            {ativos.length === 0 ? <div style={{ color: "#aaa", fontSize: 14, padding: 16, textAlign: "center" }}>Nenhum plantão ativo</div> : (
              <table style={S.table}>
                <thead><tr>{["Setor", "Médico", "CRM", "Início", "Status"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
                <tbody>
                  {ativos.map(p => (
                    <tr key={p.key} style={S.tr}>
                      <td style={S.td}>{setores.find(s => s.id === p.setorId)?.icone} {p.setorNome}</td>
                      <td style={S.td}>{p.medicoNome}</td>
                      <td style={S.td}>{p.medicoCrm}</td>
                      <td style={S.td} ><span style={{ fontFamily: "monospace", fontSize: 12 }}>{fmtTime(p.inicio)}</span></td>
                      <td style={S.td}><span style={S.badge("#2E7D32", "#E8F5E9")}>● Ativo</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Resumo */}
        <div style={{ flex: 0.85, display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={S.card}>
            <div style={S.cardTitle}>Resumo de Hoje</div>
            {[
              { icon: "👥", label: "Médicos Cadastrados", value: medicos.length, cor: "#1565C0" },
              { icon: "🟢", label: "Em Plantão Agora", value: ativos.length, cor: "#2E7D32" },
              { icon: "✅", label: "Plantões Encerrados", value: encerrados.length, cor: "#FF9800" },
              { icon: "📊", label: "Total Plantões", value: plantoes.length, cor: "#9C27B0" },
            ].map(r => (
              <div key={r.label} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: "1px solid #F0F4F8" }}>
                <span style={{ fontSize: 18 }}>{r.icon}</span>
                <span style={{ flex: 1, fontSize: 13, color: "#444" }}>{r.label}</span>
                <span style={{ fontWeight: 800, fontSize: 20, color: r.cor }}>{r.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PlantoesPage({ plantoes, setores, medicos, encerrar, setModal }) {
  const [filtro, setFiltro] = useState("todos");
  const filtered = filtro === "todos" ? plantoes : filtro === "ativo" ? plantoes.filter(p => p.status === "ativo") : plantoes.filter(p => p.status === "encerrado");
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14, alignItems: "center" }}>
        <h2 style={{ fontWeight: 700, fontSize: 20, color: "#1a1a2e" }}>Plantões</h2>
        <button style={S.btnPrimary} onClick={() => setModal("novoPlantao")}>+ Novo Plantão</button>
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        {[["todos", "Todos"], ["ativo", "Ativos"], ["encerrado", "Encerrados"]].map(([v, l]) => (
          <button key={v} style={{ border: "1px solid #E0E7EF", borderRadius: 20, padding: "5px 16px", cursor: "pointer", fontSize: 13, fontWeight: 600, background: filtro === v ? "#1565C0" : "#fff", color: filtro === v ? "#fff" : "#555" }} onClick={() => setFiltro(v)}>{l}</button>
        ))}
      </div>
      <div style={S.card}>
        <table style={S.table}>
          <thead><tr>{["Médico", "CRM", "Setor", "Início", "Fim", "Duração", "Status", "Ação"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {filtered.length === 0 ? <tr><td colSpan={8} style={{ ...S.td, textAlign: "center", color: "#aaa", padding: 24 }}>Nenhum registro</td></tr> : filtered.map(p => {
              const dur = p.fim && p.inicio ? Math.round((new Date(p.fim) - new Date(p.inicio)) / 60000) + " min" : p.status === "ativo" ? "Em curso" : "—";
              return (
                <tr key={p.key} style={S.tr}>
                  <td style={S.td}><strong>{p.medicoNome}</strong></td>
                  <td style={S.td}>{p.medicoCrm}</td>
                  <td style={S.td}>{p.setorNome}</td>
                  <td style={S.td}><span style={{ fontFamily: "monospace", fontSize: 12 }}>{fmtTime(p.inicio)}</span></td>
                  <td style={S.td}><span style={{ fontFamily: "monospace", fontSize: 12 }}>{fmtTime(p.fim)}</span></td>
                  <td style={S.td}>{dur}</td>
                  <td style={S.td}><span style={p.status === "ativo" ? S.badge("#2E7D32", "#E8F5E9") : S.badge("#555", "#F0F4F8")}>● {p.status}</span></td>
                  <td style={S.td}>
                    {p.status === "ativo" && <button style={S.btnDanger} onClick={() => encerrar(p.key, p)}>Encerrar</button>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MedicosPage({ medicos, setores, setModal, db }) {
  const [search, setSearch] = useState("");
  const filtered = medicos.filter(m => m.nome?.toLowerCase().includes(search.toLowerCase()) || m.crm?.includes(search));

  function editarSetor(key, setor) { update(ref(db, `medicos/${key}`), { setor }); }
  function resetarSenha(key) { update(ref(db, `medicos/${key}`), { senha: "1234" }); alert("Senha resetada para 1234"); }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14, alignItems: "center" }}>
        <h2 style={{ fontWeight: 700, fontSize: 20, color: "#1a1a2e" }}>Médicos Cadastrados</h2>
        <button style={S.btnPrimary} onClick={() => setModal("novoMedico")}>+ Novo Médico</button>
      </div>
      <input style={{ ...S.input, maxWidth: 320, marginBottom: 14 }} placeholder="Buscar por nome ou CRM..." value={search} onChange={e => setSearch(e.target.value)} />
      <div style={S.card}>
        <table style={S.table}>
          <thead><tr>{["Nome", "CRM", "Matrícula", "Setor", "Senha", "Ações"].map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.key} style={S.tr}>
                <td style={S.td}><strong>{m.nome}</strong></td>
                <td style={S.td}>{m.crm}</td>
                <td style={S.td}>{m.matricula || "—"}</td>
                <td style={S.td}>
                  <select style={{ ...S.select, padding: "4px 6px", fontSize: 12 }} value={m.setor || ""} onChange={e => editarSetor(m.key, e.target.value)}>
                    <option value="">Sem setor</option>
                    {setores.map(s => <option key={s.id} value={s.nome}>{s.nome}</option>)}
                  </select>
                </td>
                <td style={S.td}><span style={{ fontFamily: "monospace", letterSpacing: 2 }}>{"•".repeat(m.senha?.length || 4)}</span></td>
                <td style={S.td}>
                  <button style={{ ...S.btnSuccess, marginRight: 4 }} onClick={() => resetarSenha(m.key)}>Reset</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RelatoriosPage({ gerar, plantoes }) {
  const ativos = plantoes.filter(p => p.status === "ativo");
  const encerrados = plantoes.filter(p => p.status === "encerrado");
  const totalMin = encerrados.reduce((acc, p) => {
    if (p.fim && p.inicio) return acc + Math.round((new Date(p.fim) - new Date(p.inicio)) / 60000);
    return acc;
  }, 0);

  const relatorios = [
    { tipo: "chegada", icon: "📄", title: "Relatório de Chegada", desc: "Lista de médicos com horário de início do plantão", cor: "#EF5350" },
    { tipo: "fechamento", icon: "📊", title: "Relatório de Fechamento", desc: "Lista de médicos com horário de saída do plantão", cor: "#4CAF50" },
    { tipo: "completo", icon: "📋", title: "Relatório Completo", desc: "Resumo completo com todos os plantões e durações", cor: "#2196F3" },
    { tipo: "ausencias", icon: "📉", title: "Relatório de Ausências", desc: "Médicos sem plantão registrado hoje", cor: "#FF5722" },
  ];

  return (
    <div>
      <h2 style={{ fontWeight: 700, fontSize: 20, color: "#1a1a2e", marginBottom: 16 }}>Relatórios</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 14, marginBottom: 20 }}>
        {[
          { label: "Plantões Ativos", value: ativos.length, cor: "#2E7D32" },
          { label: "Plantões Encerrados", value: encerrados.length, cor: "#FF9800" },
          { label: "Total de Plantões", value: plantoes.length, cor: "#1565C0" },
          { label: "Horas Trabalhadas", value: Math.floor(totalMin / 60) + "h " + (totalMin % 60) + "min", cor: "#9C27B0" },
        ].map(r => (
          <div key={r.label} style={S.card}>
            <div style={{ fontSize: 13, color: "#90A4AE" }}>{r.label}</div>
            <div style={{ fontWeight: 800, fontSize: 28, color: r.cor, marginTop: 4 }}>{r.value}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 14 }}>
        {relatorios.map(r => (
          <div key={r.tipo} style={S.card}>
            <div style={{ display: "flex", gap: 12 }}>
              <span style={{ fontSize: 32 }}>{r.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: "#1a1a2e", marginBottom: 4 }}>{r.title}</div>
                <div style={{ fontSize: 12, color: "#90A4AE", marginBottom: 12 }}>{r.desc}</div>
                <button style={{ ...S.btnPrimary, background: r.cor }} onClick={() => gerar(r.tipo)}>⬇ Gerar e Baixar</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function NotifPage({ db }) {
  const [notifs, setNotifs] = useState([]);
  useEffect(() => {
    return onValue(ref(db, "notificacoes"), snap => {
      const v = snap.val() || {};
      setNotifs(Object.values(v).reverse());
    });
  }, [db]);

  return (
    <div>
      <h2 style={{ fontWeight: 700, fontSize: 20, marginBottom: 16 }}>Notificações em Tempo Real</h2>
      <div style={S.card}>
        {notifs.length === 0 ? <div style={{ color: "#aaa", textAlign: "center", padding: 24 }}>Sem notificações</div> : notifs.map((n, i) => (
          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 0", borderBottom: "1px solid #F0F4F8" }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: n.cor === "green" ? "#E8F5E9" : "#FFEBEE", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>
              {n.cor === "green" ? "✅" : "🔴"}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: "#333" }}>{n.texto}</div>
              <div style={{ fontSize: 11, color: "#90A4AE", marginTop: 2 }}>{n.hora}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

import { onValue } from "firebase/database";
