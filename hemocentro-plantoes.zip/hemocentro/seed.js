// seed.js — rode UMA VEZ para popular o banco de dados
// node seed.js  (após configurar as variáveis de ambiente)

const { initializeApp } = require("firebase/app");
const { getDatabase, ref, set } = require("firebase/database");

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.REACT_APP_FIREBASE_DATABASE_URL,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// ── MÉDICOS (senha padrão: 1234) ──────────────────────────────────────────
const medicos = [
  // GESTOR
  { crm: "11707", nome: "Rodrigo Cahuana Chipayo", matricula: "GESTOR", funcao: "Gestor", setor: null, role: "gestor", senha: "1234" },

  // TRIAGEM CLÍNICA
  { crm: "4331",  nome: "Ana Thereza de Medeiros Correia",    matricula: "946.847-1", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "17755", nome: "Andre Barros Teixeira",              matricula: "926.206-7", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "17198", nome: "Antônio Jose Pedrosa Formiga",       matricula: "679.935-3", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "18208", nome: "Caio Henrique Santos Costa",         matricula: "927.178-3", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "18851", nome: "Dayanna Joyce de Lacerda Ferreira",  matricula: "929.505-4", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "13693", nome: "Gabriella Palitot Bandeira",         matricula: "924.164-7", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "9828",  nome: "Hellen Karla Sa Fernandes da Costa", matricula: "941.736-2", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "15679", nome: "Maria das Graças Nunes",             matricula: "919.787-7", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "17254", nome: "Maria Fernada Lopes Linhares",       matricula: "926.355-1", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "19124", nome: "Matheus Eduardo Santos Madruga",     matricula: "927.812-5", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "8356",  nome: "Pedro Augusto de Oliveira Feitosa",  matricula: "184.626-9", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "19644", nome: "Raissa Rackel Pinheiro dos Santos",  matricula: "929.841-0", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
  { crm: "14074", nome: "Ravel Alves Martins",                matricula: "946.755-6", funcao: "Médico(a)", setor: null, role: "plantonista", senha: "1234" },
];

const setores = [
  { id: "triagem",     nome: "Triagem Clínica",             icone: "🩺", cor: "#2196F3", vagas: 5 },
  { id: "orientacao",  nome: "Orientação",                  icone: "💬", cor: "#4CAF50", vagas: 4 },
  { id: "intercorr",   nome: "Intercorrências",             icone: "⚠️", cor: "#FF9800", vagas: 3 },
  { id: "transfusao",  nome: "Ambulatório de Transfusão",   icone: "🩸", cor: "#9C27B0", vagas: 4 },
];

async function seed() {
  console.log("🌱 Populando banco de dados...");

  // Setores
  for (const s of setores) {
    await set(ref(db, `setores/${s.id}`), s);
  }
  console.log("✅ Setores criados");

  // Médicos
  for (const m of medicos) {
    const key = `crm_${m.crm}`;
    await set(ref(db, `medicos/${key}`), m);
  }
  console.log("✅ Médicos criados");

  console.log("\n🎉 Seed concluído! Banco populado com sucesso.");
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
