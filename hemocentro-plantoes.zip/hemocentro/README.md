# 🩸 Hemocentro JP — Gestão de Plantões Médicos

Sistema web em tempo real para gestão de plantões médicos do Hemocentro de João Pessoa.

---

## 🚀 PASSO A PASSO COMPLETO PARA COLOCAR NO AR

### PASSO 1 — Criar projeto no Firebase (banco de dados em tempo real)

1. Acesse **https://console.firebase.google.com**
2. Clique em **"Criar um projeto"**
3. Nome: `hemocentro-joaopessoa` → clique em Continuar até finalizar
4. No menu lateral esquerdo, clique em **"Realtime Database"**
5. Clique em **"Criar banco de dados"**
6. Escolha **"Iniciar no modo de teste"** → Próximo → Concluído
7. No menu lateral, clique em **"Configurações do projeto"** (ícone de engrenagem ⚙️)
8. Role para baixo até **"Seus apps"** → clique em **"</> Web"**
9. Nome do app: `hemocentro-web` → clique em **"Registrar app"**
10. **COPIE os dados do `firebaseConfig`** — você vai precisar no Passo 3

O firebaseConfig tem esse formato:
```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "hemocentro-joaopessoa.firebaseapp.com",
  databaseURL: "https://hemocentro-joaopessoa-default-rtdb.firebaseio.com",
  projectId: "hemocentro-joaopessoa",
  storageBucket: "hemocentro-joaopessoa.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

---

### PASSO 2 — Subir o código no GitHub

1. Acesse **https://github.com** e crie uma conta (se não tiver)
2. Clique em **"New repository"** (botão verde)
3. Nome: `hemocentro-plantoes`
4. Deixe **Público** → clique em **"Create repository"**
5. Na próxima tela, clique em **"uploading an existing file"**
6. Arraste **toda a pasta `hemocentro`** para a área de upload
7. Clique em **"Commit changes"**

---

### PASSO 3 — Deploy no Vercel (link público)

1. Acesse **https://vercel.com** → faça login com sua conta GitHub
2. Clique em **"Add New Project"**
3. Selecione o repositório `hemocentro-plantoes` → clique em **"Import"**
4. Em **"Environment Variables"**, adicione uma por uma:

| Nome da variável | Valor (da etapa 1) |
|---|---|
| `REACT_APP_FIREBASE_API_KEY` | sua apiKey |
| `REACT_APP_FIREBASE_AUTH_DOMAIN` | seu authDomain |
| `REACT_APP_FIREBASE_DATABASE_URL` | seu databaseURL |
| `REACT_APP_FIREBASE_PROJECT_ID` | seu projectId |
| `REACT_APP_FIREBASE_STORAGE_BUCKET` | seu storageBucket |
| `REACT_APP_FIREBASE_MESSAGING_SENDER_ID` | seu messagingSenderId |
| `REACT_APP_FIREBASE_APP_ID` | seu appId |

5. Clique em **"Deploy"** — aguarde ~2 minutos
6. O Vercel vai gerar um link como: `https://hemocentro-plantoes.vercel.app`

---

### PASSO 4 — Popular o banco com os médicos

Após o deploy, abra o console do Firebase:

1. Vá em **Realtime Database** → clique em ✏️ (editar/importar dados)
2. Clique nos **3 pontinhos** → **"Importar JSON"**
3. Cole o conteúdo do arquivo `dados_iniciais.json` (gerado abaixo)

**OU** execute o seed via terminal:
```bash
cd hemocentro
npm install
node seed.js
```

---

## 👤 CREDENCIAIS DE ACESSO

### Gestor (acesso total):
- **CRM:** `11707`
- **Senha:** `1234`
- **Nome:** Rodrigo Cahuana Chipayo

### Plantonistas (todos começam com senha 1234):

| Nome | CRM | Senha |
|---|---|---|
| Ana Thereza de Medeiros Correia | 4331 | 1234 |
| Andre Barros Teixeira | 17755 | 1234 |
| Antônio Jose Pedrosa Formiga | 17198 | 1234 |
| Caio Henrique Santos Costa | 18208 | 1234 |
| Dayanna Joyce de Lacerda Ferreira | 18851 | 1234 |
| Gabriella Palitot Bandeira | 13693 | 1234 |
| Hellen Karla Sa Fernandes da Costa | 9828 | 1234 |
| Maria das Graças Nunes | 15679 | 1234 |
| Maria Fernada Lopes Linhares | 17254 | 1234 |
| Matheus Eduardo Santos Madruga | 19124 | 1234 |
| Pedro Augusto de Oliveira Feitosa | 8356 | 1234 |
| Raissa Rackel Pinheiro dos Santos | 19644 | 1234 |
| Ravel Alves Martins | 14074 | 1234 |

**Login:** CRM (só números, sem "CRM/PB") + senha

---

## ✅ O QUE O SISTEMA FAZ

### Para o Gestor (Rodrigo CRM 11707):
- ✅ Ver todos os plantões em tempo real
- ✅ Iniciar plantões para qualquer médico
- ✅ Encerrar plantões
- ✅ Gerenciar médicos (cadastrar, atribuir setor, resetar senha)
- ✅ Gerar relatórios (chegada, fechamento, completo, ausências)
- ✅ Ver notificações de todas as ações
- ✅ Dashboard com totais em tempo real

### Para o Plantonista:
- ✅ Iniciar próprio plantão (registra horário exato)
- ✅ Encerrar próprio plantão (registra horário exato)
- ✅ Ver escala geral ao vivo (quem está de plantão agora)
- ✅ Ver histórico próprio de plantões
- ✅ Relógio em tempo real na tela

---

## 📱 COMO ENVIAR O LINK AOS PLANTONISTAS

Após o deploy, envie via WhatsApp:

```
🩸 *Hemocentro JP — Sistema de Plantões*

Acesse: https://hemocentro-plantoes.vercel.app

Login: seu CRM (só números)
Senha: 1234

Pelo sistema você pode:
• Iniciar e encerrar seu plantão
• Ver a escala do dia em tempo real
• Consultar seu histórico
```
